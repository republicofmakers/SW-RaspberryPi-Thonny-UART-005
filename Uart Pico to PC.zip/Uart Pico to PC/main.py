from machine import I2C, Pin, SPI, UART
import time
from ST7735 import TFT
from sysfont import sysfont
from sht4x import SHT4X  # Your driver

# --- SPI0 for TFT (GPIO18=SCK, GPIO19=MOSI, GPIO21=DC, GPIO20=RST, GPIO22=CS) ---
spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)

# --- I2C1 for SHT4x Sensor (GPIO2=SDA, GPIO3=SCL) ---
i2c = I2C(1, sda=Pin(2), scl=Pin(3), freq=100_000)

# --- UART0 for TX/RX (TX=GPIO0, RX=GPIO1) ---
uart = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))

# --- Intro Screen ---
tft.fill(TFT.BLACK)
tft.text((0, 0), "RP2040", TFT.RED, sysfont, 2)
tft.text((0, 20), "UART TEST", TFT.RED, sysfont, 2)
tft.text((0, 40), "Ceyhun Pempeci", TFT.BLUE, sysfont, 2)
tft.text((0, 65), "2025", TFT.GREEN, sysfont, 2)
time.sleep(5)

# --- Init SHT4x Sensor ---
try:
    sht = SHT4X(i2c)
    print("Sensor initialized.")
    uart.write("SHT4x sensor initialized.\n")
except Exception as e:
    tft.fill(TFT.BLACK)
    tft.text((10, 30), "Init Failed", TFT.RED, sysfont, 2)
    uart.write("SHT4x init failed.\n")
    print("SHT4x init error:", e)
    raise

# --- Main Loop ---
while True:
    try:
        temp = sht.temperature
        hum = sht.relative_humidity

        # Format and send via UART
        uart_msg = "Temp: {:.2f} C, Hum: {:.2f} %\n".format(temp, hum)
        uart.write(uart_msg)
        print(uart_msg)

        # Show TEMP on TFT
        tft.fill(TFT.BLACK)
        tft.text((10, 5), "TEMPERATURE", TFT.RED, sysfont, 2)
        tft.text((10, 30), "{:.2f} C".format(temp), TFT.GREEN, sysfont, 2)
        time.sleep(2)

        # Show HUM on TFT
        tft.fill(TFT.BLACK)
        tft.text((10, 5), "HUMIDITY", TFT.RED, sysfont, 2)
        tft.text((10, 30), "{:.2f} %".format(hum), TFT.GREEN, sysfont, 2)
        time.sleep(2)

    except Exception as e:
        error_msg = "Sensor error: {}\n".format(e)
        uart.write(error_msg)
        print(error_msg)
        tft.fill(TFT.BLACK)
        tft.text((10, 30), "Sensor Error", TFT.RED, sysfont, 2)
        time.sleep(2)
